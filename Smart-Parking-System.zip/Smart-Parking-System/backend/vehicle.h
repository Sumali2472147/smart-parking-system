#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include <string>

using namespace std;

class Vehicle
{
private:

    string vehicleNumber;
    string ownerName;

public:

    Vehicle(string number="", string owner="");

    string getVehicleNumber();

    string getOwnerName();
};

#endif