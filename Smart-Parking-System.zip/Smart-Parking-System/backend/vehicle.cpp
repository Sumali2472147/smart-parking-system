#include "vehicle.h"

Vehicle::Vehicle(string number, string owner)
{
    vehicleNumber = number;
    ownerName = owner;
}

string Vehicle::getVehicleNumber()
{
    return vehicleNumber;
}

string Vehicle::getOwnerName()
{
    return ownerName;
}