#include <iostream>
#include <fstream>
#include <string>

#include "parkingsystem.h"

using namespace std;


int main()
{
    ParkingSystem parking(5);


    ifstream file("parking_data.txt");


    string vehicle;
    string owner;


    while(file >> vehicle >> owner)
    {
        Vehicle v(vehicle, owner);

        parking.parkVehicle(v);
    }


    file.close();


    cout << "Smart Parking Backend Running\n";


    parking.display();


    return 0;
}