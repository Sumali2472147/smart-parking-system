#include "parkingsystem.h"



ParkingSystem::ParkingSystem(int size)
{

    totalSlots=size;

}



bool ParkingSystem::parkVehicle(Vehicle v)
{

    if(slots.size() >= totalSlots)
    {
        return false;
    }


    slots.push_back(v);

    return true;

}



void ParkingSystem::removeVehicle(int index)
{

    if(index >=0 && index < slots.size())
    {
        slots.erase(slots.begin()+index);
    }

}



void ParkingSystem::display()
{

    cout<<"\n----- Parking Status -----\n";


    for(int i=0;i<slots.size();i++)
    {

        cout<<"Slot "<<i+1<<endl;

        cout<<"Vehicle : "
        <<slots[i].getVehicleNumber()<<endl;


        cout<<"Owner : "
        <<slots[i].getOwnerName()<<endl;


    }


}