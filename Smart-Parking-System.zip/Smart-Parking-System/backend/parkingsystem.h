#ifndef PARKINGSYSTEM_H
#define PARKINGSYSTEM_H


#include <iostream>
#include <vector>

#include "vehicle.h"


using namespace std;


class ParkingSystem
{

private:

    vector<Vehicle> slots;

    int totalSlots;



public:

    ParkingSystem(int size);


    bool parkVehicle(Vehicle v);


    void removeVehicle(int index);


    void display();

};


#endif