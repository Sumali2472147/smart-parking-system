function parkVehicle(){

    let vehicle = document.getElementById("vehicle").value;
    let owner = document.getElementById("owner").value;


    if(vehicle=="" || owner=="")
    {
        alert("Please enter details");
        return;
    }


    fetch("http://127.0.0.1:5000/park",
    {
        method:"POST",

        headers:
        {
            "Content-Type":"application/json"
        },

        body:JSON.stringify(
        {
            vehicle:vehicle,
            owner:owner
        })

    })

    .then(response=>response.json())

   .then(data=>{

    console.log(data);

    if(data.error)
    {
        alert(data.error);
    }
    else
    {
        alert(data.message);
    }

    loadSlots();

})

    .catch(error=>{

        console.log(error);
        alert("Server Error");

    });

}



function loadSlots(){

    fetch("http://127.0.0.1:5000/status")

    .then(response=>response.json())

    .then(data=>{


        let slots =
        document.getElementById("slots");


        let html="";


        for(let i=0;i<3;i++)
        {

            if(data[i])
            {

                html += `

                <div class="slot booked">

                SLOT ${i+1} 🔴

                <br>

                Vehicle:
                ${data[i].vehicle}

                <br>

                Owner:
                ${data[i].owner}

                </div>

                `;

            }

            else
            {

                html += `

                <div class="slot available">

                SLOT ${i+1} 🟢

                <br>

                Available

                </div>

                `;

            }

        }


        slots.innerHTML=html;



        let table =
        document.getElementById("vehicleTable");


        let rows=`

        <tr>
        <th>Vehicle Number</th>
        <th>Owner Name</th>
        </tr>

        `;


        data.forEach(function(v){

            rows +=`

            <tr>

            <td>${v.vehicle}</td>

            <td>${v.owner}</td>

            </tr>

            `;

        });


        table.innerHTML=rows;



        document.getElementById("total").innerHTML=3;

        document.getElementById("occupied").innerHTML=data.length;

        document.getElementById("available").innerHTML=3-data.length;


    });


}



function exitVehicle(){

    let vehicle = document.getElementById("exitVehicle").value;


    fetch("http://127.0.0.1:5000/exit",
    {
        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify({
            vehicle: vehicle
        })

    })

    .then(response=>response.json())

     .then(data=>{

    let receipt = `

    <html>
    <head>
    <title>Parking Receipt</title>

    <style>
    body{
        font-family: Arial;
        padding:20px;
    }

    .receipt{
        width:300px;
        border:2px solid black;
        padding:20px;
    }

    h2{
        text-align:center;
    }

    </style>

    </head>


    <body>

    <div class="receipt">

    <h2>Smart Parking</h2>

    <hr>

    Vehicle : ${data.vehicle}
    <br><br>

    Parking : ${data.parking}
    <br><br>

    Duration : ${data.minutes} Minutes
    <br><br>

    Amount : ₹${data.fee}

    <br><br>

    Exit Time : ${data.exit_time}

    <hr>

    <button onclick="window.print()">
    Print Receipt
    </button>


    </div>

    </body>

    </html>

    `;


    let win = window.open("");

    win.document.write(receipt);

    win.document.close();


    loadSlots();
    loadBookings();

})

    .catch(error=>{

        console.log(error);

        alert("Server Error");

    });

}
function logout(){

    localStorage.removeItem("login");

    alert("Logout Successful");

    window.location.href="/login";

}

// Parking Map

// Multiple Parking Locations Map

let map = L.map('map').setView(
    [31.3260,75.5762],
    13
);


L.tileLayer(
'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
{
    attribution:'OpenStreetMap'
}
).addTo(map);



let parkingData = [

{
    name:"City Parking",
    lat:31.3260,
    lon:75.5762,
    slots:5
},

{
    name:"Mall Parking",
    lat:31.3170,
    lon:75.5800,
    slots:10
},

{
    name:"Railway Parking",
    lat:31.3255,
    lon:75.5790,
    slots:8
}

];



parkingData.forEach(function(p){


let marker = L.marker(
[p.lat,p.lon]
)
.addTo(map);



marker.bindPopup(

`
<h3>${p.name}</h3>

Available Slots:
${p.slots}

<br><br>

<button onclick="bookParking('${p.name}')">
Book Parking
</button>

`

);


});

function bookParking(name)
{

    let vehicle = prompt("Enter Vehicle Number");

    let owner = prompt("Enter Owner Name");


    fetch("http://127.0.0.1:5000/book",
    {
        method:"POST",

        headers:
        {
            "Content-Type":"application/json"
        },

        body:JSON.stringify(
        {
            parking_name:name,
            vehicle:vehicle,
            owner:owner
        })
    })

    .then(response => response.json())

   .then(data =>
{
    console.log(data);

    alert(data.message || data.error);

    loadBookings();

    location.reload();

})

    .catch(error =>
    {
        console.log(error);

        alert("Server Error");
    });

}



function loadBookings()
{

fetch("http://127.0.0.1:5000/bookings")


.then(response=>response.json())


.then(data=>{


let table =
document.getElementById("bookingTable");


let rows = `

<tr>

<th>
Parking Name
</th>

<th>
Vehicle
</th>

<th>
Owner
</th>

</tr>

`;



data.forEach(function(b){

rows += `

<tr>

<td>${b.parking_name}</td>

<td>${b.vehicle}</td>

<td>${b.owner}</td>

</tr>

`;

});

table.innerHTML = rows;


});


}


window.onload=function(){

    loadBookings();

    loadSlots();

}

function login()
{

    let email =
    document.getElementById("username").value.trim();


    let password =
    document.getElementById("password").value.trim();


    fetch("/login",
    {
        method:"POST",

        headers:
        {
            "Content-Type":"application/json"
        },

        body:JSON.stringify({

            email: email,
            password: password

        })

    })


    .then(response=>response.json())


    .then(data=>{

        if(data.error)
        {
            alert(data.error);
        }
        else
        {
            alert(data.message);

            localStorage.setItem(
                "login",
                "true"
            );

            window.location.href="/login";
        }

    })


    .catch(error=>{

        console.log(error);

        alert("Server Error");

    });

}